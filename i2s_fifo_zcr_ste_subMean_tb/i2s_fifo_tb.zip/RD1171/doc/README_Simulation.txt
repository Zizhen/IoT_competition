---------------------------------------------------------------------------------------------------

                                ReadMe File for Simulation

  	Simulation Set-up:
 	1. Open Standalone Active HDL software from the iCEcube2 Installation:
	IMP NOTE: USE iCEcube2 VERSION- "2012.06" or ABOVE.		
		a. Go to "Start>All Programs>Lattice iCEcube2>" and select "AVHDL"
		b. The Active HDL software will open.
   	2. To successfully run the script, make the following change:
		a. Open the "RD1171.do" script from path "RD1171\simulation\aldec".
		b. Update the "set path  <User Directory >\RD1171\Project" line, with your directory path.		
	3. Open the pull down menu "Tools" and select  "Execute Macro". 
	4. Browse to "RD1171\simulation\aldec".
	5. Select the macro RD1171.do. This will automatically complete the simulation.
	6. A new simulation directory "aldec_sim" will be created in the Projects folder.
	
	Simulation Execution Sequence:
	1. Start of Simulation.
	2. Simulation Ends after 10 ms.
---------------------------------------------------------------------------------------------------  
